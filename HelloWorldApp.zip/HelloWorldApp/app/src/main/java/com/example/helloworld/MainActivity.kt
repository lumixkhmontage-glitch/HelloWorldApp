package com.example.helloworld

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.Toast
import android.view.View

/**
 * A simple activity that shows a toast saying "Hello world" when the user
 * taps anywhere on the screen. A dedicated "Torna Indietro" button allows
 * navigating back to the previous screen (or closing the app if this is
 * the first activity).
 */
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // The root view fills the entire screen. When it's tapped, show a toast.
        val rootView = findViewById<View>(R.id.root_view)
        rootView.setOnClickListener {
            Toast.makeText(this, "Hello world", Toast.LENGTH_SHORT).show()
        }

        // Clicking the back button finishes this activity.
        val backButton: Button = findViewById(R.id.back_button)
        backButton.setOnClickListener {
            finish()
        }
    }
}